
AI-Based Resource Usage Advisor – Web Prototype

This is a simple Flask web application demonstrating a conceptual AI-based
resource usage advisory system.

How to run:
1. Install Flask: pip install flask
2. Run: python app.py
3. Open browser: http://127.0.0.1:5000

Purpose:
Educational and conceptual prototype for the
1M1B AI for Sustainability Virtual Internship.
